# EmoVibe — Starter (Full site)

This starter includes:
- Multi-page static frontend (index, chat, treehole, test)
- Vercel-compatible serverless API endpoints (/api/chat, /api/tree)
- Uses OPENAI_API_KEY (from Vercel Environment Variables) for chat
- Optional Supabase for persistent treehole storage (configure NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY)

## Quick local test (recommended)
- Install Vercel CLI: `npm i -g vercel`
- Install deps: `npm install`
- Run locally with Vercel dev: `vercel dev` (this will run serverless functions locally)
- Open http://localhost:3000

## Deployment (Vercel)
1. Create a GitHub repo and push this project.
2. Import the repo into Vercel (New Project -> Import Git Repository).
3. In Vercel Project Settings -> Environment Variables, add:
   - OPENAI_API_KEY  = your_openai_key
   - (optional) NEXT_PUBLIC_SUPABASE_URL = https://your.supabase.co
   - (optional) NEXT_PUBLIC_SUPABASE_ANON_KEY = your_anon_key
   - (optional) SUPABASE_SERVICE_KEY = (if using server-side supabase features)
4. Deploy. Vercel will host static pages and serverless APIs automatically.

## Notes & Security
- Do NOT commit your secret keys to GitHub. Use Vercel Environment Variables.
- If you don't configure Supabase, the treehole endpoint will use an in-memory store (non-persistent) and is only for testing.

## Files
- /api/chat.js   -> serverless proxy to OpenAI
- /api/tree.js   -> treehole store (Supabase optional)
- /index.html    -> homepage
- /chat.html     -> chat UI (calls /api/chat)
- /treehole.html -> anonymous posts (calls /api/tree)
- /test.html     -> simple emotion test page
