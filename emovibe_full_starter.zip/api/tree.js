// Simple treehole serverless endpoint. If Supabase env vars are provided, it will use Supabase for persistence.
const fetch = require('node-fetch');
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const postsCache = []; // fallback (non-persistent)
module.exports = async (req, res) => {
  try {
    if(req.method === 'GET') {
      if(SUPABASE_URL && SUPABASE_ANON) {
        const r = await fetch(`${SUPABASE_URL}/rest/v1/treehole?select=*&order=created_at.desc`, {headers: {'apikey': SUPABASE_ANON, 'Authorization': `Bearer ${SUPABASE_ANON}`}});
        const data = await r.json();
        return res.status(200).json({posts: data});
      } else {
        return res.status(200).json({posts: postsCache});
      }
    } else if(req.method === 'POST') {
      const body = req.body || {};
      const content = (body.content || '').toString().slice(0,1000);
      if(!content) return res.status(400).json({error:'empty'});
      if(SUPABASE_URL && SUPABASE_ANON) {
        await fetch(`${SUPABASE_URL}/rest/v1/treehole`, {
          method:'POST',
          headers:{'apikey': SUPABASE_ANON, 'Authorization': `Bearer ${SUPABASE_ANON}`, 'Content-Type':'application/json'},
          body: JSON.stringify({content})
        });
        return res.status(200).json({ok:true});
      } else {
        postsCache.push({content, created_at: new Date().toISOString()});
        return res.status(200).json({ok:true});
      }
    } else {
      res.setHeader('Allow','GET,POST');
      res.status(405).end('Method Not Allowed');
    }
  } catch(err) {
    console.error(err);
    res.status(500).json({error: err.message});
  }
}
